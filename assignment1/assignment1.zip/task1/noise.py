import cv2
import numpy as np
from utils import *

"""
This is main function for task 1.
It takes 2 arguments,
'src_img_path' is path for source image.
'dst_img_path' is path for output image, where your result image should be saved.

You should load image in 'src_img_path', and then perform task 1 of your assignment 1,
and then save your result image to 'dst_img_path'.
"""
def task1(src_img_path, clean_img_path, dst_img_path):
    kernel_sizes = [3, 5, 7, 9, 11, 13, 15]

    img = cv2.imread(src_img_path)
    clean_img = cv2.imread(clean_img_path)
    result_img = np.zeros(img.shape)

    #name_dic = {0:'average', 1:'median', 2:'bilateral', 3:'point', 4:'gaussian'}
    #optimal_kernel_size = 0
    min_rms = np.Inf
    #method = ""

    for kernel_size in kernel_sizes:
        G_s = 75
        G_r = 75
        results = []
        results.append(apply_average_filter(img, kernel_size))
        results.append(apply_median_filter(img, kernel_size))
        results.append(apply_bilateral_filter(img, kernel_size, G_s, G_r))
        results.append(apply_point_filter(img, kernel_size))
        results.append(apply_gaussian_filter(img, kernel_size))
        for i, result in enumerate(results):
            rms = calculate_rms_cropped(result, clean_img)
            if rms < min_rms:
                min_rms = rms
                result_img = result
                #method = name_dic[i]
                #optimal_kernel_size = kernel_size

    #print(method, optimal_kernel_size, min_rms)
    cv2.imwrite(dst_img_path, result_img)
    return

"""
You should implement average filter convolution algorithm in this function.
It takes 2 arguments,
'img' is source image, and you should perform convolution with average filter.
'kernel_size' is a int value, which determines kernel size of average filter.

You should return result image.
"""
def apply_average_filter(img, kernel_size):
    y, x, _ = img.shape
    new_img = np.zeros_like(img)
    #diameter is used as the number of zero padding lines and to compute center of the kernel in global scale.
    diameter = kernel_size//2
    img = np.pad(img, ((diameter, diameter), (diameter, diameter), (0, 0)), 'constant')

    for i in range(y):
        for j in range(x):
            new_img[i, j] = np.sum(img[i:i + kernel_size, j:j + kernel_size], axis=(0, 1)) / kernel_size ** 2
    new_img = new_img.astype(np.uint8)
    return new_img


"""
You should implement median filter convolution algorithm in this function.
It takes 2 arguments,
'img' is source image, and you should perform convolution with median filter.
'kernel_size' is a int value, which determines kernel size of median filter.

You should return result image.
"""


def apply_median_filter(img, kernel_size):
    y, x, _ = img.shape
    new_img = np.zeros_like(img)
    diameter = kernel_size//2
    img = np.pad(img, ((diameter, diameter), (diameter, diameter), (0, 0)), 'constant')
    for i in range(y):
        for j in range(x):
            new_img[i, j] = np.median(img[i:i+kernel_size, j:j+kernel_size], axis=(0,1))
    return new_img


"""
You should implement convolution with additional filter.
You can use any filters for this function, except average, median filter.
It takes at least 2 arguments,
'img' is source image, and you should perform convolution with median filter.
'kernel_size' is a int value, which determines kernel size of average filter.
'sigma_s' is a int value, which is a sigma value for G_s
'sigma_r' is a int value, which is a sigma value for G_r

You can add more arguments for this function if you need.

You should return result image.
"""


def apply_bilateral_filter(img, kernel_size, sigma_s, sigma_r):
    y, x, _ = img.shape
    new_img = np.zeros_like(img)
    diameter = kernel_size // 2
    img = np.pad(img, ((diameter, diameter), (diameter, diameter), (0, 0)), 'constant')
    row, col = np.mgrid[-diameter:diameter + 1, -diameter:diameter + 1]
    space_norm = np.sqrt(np.square(row) + np.square(col))
    G_s_mask = gaussian(space_norm, sigma_s)

    for i in range(y):
        for j in range(x):
            for k in range(3):
                range_diff = img[i:i + kernel_size, j:j + kernel_size, k] - img[i + diameter, j + diameter, k]
                G_r_mask = gaussian(range_diff, sigma_r)
                kernel = G_s_mask * G_r_mask
                Wp = kernel.sum()
                new_img[i, j, k] = (1 / Wp) * (img[i:i + kernel_size, j:j + kernel_size, k]*kernel).sum()
    new_img = new_img.astype(np.uint8)
    return new_img

'''
custom functions.
'''
def gaussian(x, sigma):
    return np.exp(-0.5 * (x / sigma) ** 2)

def apply_point_filter(img, kernel_size):
    y, x, _ = img.shape
    new_img = np.zeros_like(img)
    diameter = kernel_size//2
    img = np.pad(img, ((diameter, diameter), (diameter, diameter), (0, 0)), 'constant')
    for i in range(y):
        for j in range(x):
            for k in range(3):
                if img[i+diameter, j+diameter, k] == 0 or img[i+diameter, j+diameter, k] == 255:
                    new_img[i,j,k] = (img[i:i+kernel_size, j:j+kernel_size, k].sum() - img[i+diameter, j+diameter, k])/(kernel_size**2 - 1)
                else:
                    new_img[i,j,k] = img[i+diameter, j+diameter, k]
    return new_img

def apply_gaussian_filter(img, kernel_size):
    sigma = np.sqrt(kernel_size)/2
    y, x, _ = img.shape
    new_img = np.zeros_like(img)
    diameter = kernel_size // 2
    img = np.pad(img, ((diameter, diameter), (diameter, diameter), (0, 0)), 'constant')
    row, col = np.mgrid[-diameter:diameter + 1, -diameter:diameter + 1]
    space_norm = np.sqrt(np.square(row) + np.square(col))
    gaussain_filter = gaussian(space_norm, sigma)
    gaussain_filter /= gaussain_filter.sum()
    for i in range(y):
        for j in range(x):
            elementwise = img[i:i+kernel_size, j:j+kernel_size] * gaussain_filter.reshape((kernel_size,kernel_size,1))
            new_img[i,j] = np.sum(elementwise, axis=(0,1))
    new_img = new_img.astype(np.uint8)
    return new_img