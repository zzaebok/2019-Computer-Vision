import cv2
import matplotlib.pyplot as plt
import numpy as np

##### To-do #####

def my_fft(img):
    m,n = img.shape
    fft_img = np.zeros(img.shape, dtype=complex)
    denominator = (1 / (m*n))
    for r in range(m):
        for c in range(n):
            tmp_result = 0
            for k_r in range(m):
                for k_c in range(n):
                    tmp_result += img[k_r, k_c] * np.exp(-1j*2*np.pi * ((k_r*r)/m + (k_c*c)/n))
            fft_img[r, c] = denominator * tmp_result
    return fft_img

def my_ifft(fr_img):
    m,n = fr_img.shape
    re_img = np.zeros_like(fr_img, dtype=complex)
    for r in range(m):
        for c in range(n):
            tmp_result = 0
            for k_r in range(m):
                for k_c in range(n):
                    tmp_result += fr_img[k_r, k_c] * np.exp(1j*2*np.pi * ((k_r*r)/m + (k_c*c)/n))
            re_img[r, c] = m*n*tmp_result
    return re_img

def shift(mat):
    half = [dim//2 for dim in mat.shape]
    axes = tuple(range(mat.ndim))
    return np.roll(mat, half, axes)

def ishift(mat):
    half = [- (dim // 2) for dim in mat.shape]
    axes = tuple(range(mat.ndim))
    return np.roll(mat, half, axes)

def fm_spectrum(img):
    ft_img = np.fft.fft2(img)
    centered_ft_img = shift(ft_img)
    centered_ft_img = abs(centered_ft_img)
    magnitude_spectrum = np.log(centered_ft_img)
    return magnitude_spectrum

def low_pass_filter(img, th=20):
    r, c = img.shape
    y, x = np.mgrid[:r, :c]
    lp_filter = np.where(np.sqrt((y-r//2)**2 + (x-c//2)**2) <= th, 1, 0)
    #sequence: fft -> shift -> filter -> shift -> ifft
    filtered = shift(np.fft.fft2(img)) * lp_filter
    filtered = ishift(filtered)
    res = np.fft.ifft2(filtered).real.astype(np.int)
    return res

def high_pass_filter(img, th=30):
    r, c = img.shape
    y, x = np.mgrid[:r, :c]
    hp_filter = np.where(np.sqrt((y - r // 2) ** 2 + (x - c // 2) ** 2) <= th, 0, 1)
    # sequence: fft -> shift -> filter -> shift -> ifft
    filtered = shift(np.fft.fft2(img)) * hp_filter
    filtered = ishift(filtered)
    res = np.fft.ifft2(filtered).real.astype(np.int)
    return res

def denoise1(img):
    r, c = img.shape
    filter = np.ones(img.shape)
    center_r = r//2
    center_c = c//2
    filter[center_r - 60:center_r - 40, center_c + 40:center_c + 60] = 0
    filter[center_r + 40:center_r + 60, center_c + 40:center_c + 60] = 0
    filter[center_r - 60:center_r - 40, center_c - 60:center_c - 40] = 0
    filter[center_r + 40:center_r + 60, center_c - 60:center_c - 40] = 0
    filtered = shift(np.fft.fft2(img)) * filter
    filtered = ishift(filtered)
    res = np.fft.ifft2(filtered).real.astype(np.int)
    cv2.imwrite('denoised1.png', res)
    return res

def denoise2(img):
    low_limit = 40
    high_limit = 50
    r, c = img.shape
    filter = np.ones(img.shape)
    center_r = r // 2
    center_c = c // 2
    for i in range(r):
        for j in range(c):
            if low_limit <= np.sqrt((i - center_r) ** 2 + (j - center_c) ** 2) <= high_limit:
                filter[i,j] = 0
    filtered = shift(np.fft.fft2(img)) * filter
    filtered = ishift(filtered)
    res = np.fft.ifft2(filtered).real.astype(np.int)
    cv2.imwrite('denoised2.png', res)
    return res

#################

if __name__ == '__main__':
    img = cv2.imread('task2_sample.png', cv2.IMREAD_GRAYSCALE)
    cor1 = cv2.imread('task2_corrupted_1.png', cv2.IMREAD_GRAYSCALE)
    cor2 = cv2.imread('task2_corrupted_2.png', cv2.IMREAD_GRAYSCALE)

    def drawFigure(loc, img, label):
        plt.subplot(*loc), plt.imshow(img, cmap='gray')
        plt.title(label), plt.xticks([]), plt.yticks([])

    drawFigure((2,7,1), img, 'Original')
    drawFigure((2,7,2), low_pass_filter(img), 'Low-pass')
    drawFigure((2,7,3), high_pass_filter(img), 'High-pass')
    drawFigure((2,7,4), cor1, 'Noised')
    drawFigure((2,7,5), denoise1(cor1), 'Denoised')
    drawFigure((2,7,6), cor2, 'Noised')
    drawFigure((2,7,7), denoise2(cor2), 'Denoised')

    drawFigure((2,7,8), fm_spectrum(img), 'Spectrum')
    drawFigure((2,7,9), fm_spectrum(low_pass_filter(img)), 'Spectrum')
    drawFigure((2,7,10), fm_spectrum(high_pass_filter(img)), 'Spectrum')
    drawFigure((2,7,11), fm_spectrum(cor1), 'Spectrum')
    drawFigure((2,7,12), fm_spectrum(denoise1(cor1)), 'Spectrum')
    drawFigure((2,7,13), fm_spectrum(cor2), 'Spectrum')
    drawFigure((2,7,14), fm_spectrum(denoise2(cor2)), 'Spectrum')


    plt.show()